import { google } from 'googleapis'
import nodemailer from 'nodemailer'

const SHEET_ID = process.env.SHEET_ID
const ADMIN_EMAIL = process.env.ADMIN_EMAIL

async function appendToSheet(lead){
  const clientEmail = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL
  let privateKey = process.env.GOOGLE_PRIVATE_KEY
  if(!clientEmail || !privateKey || !SHEET_ID) throw new Error('Missing Google Sheets credentials')
  privateKey = privateKey.replace(/\\n/g,'\n')
  const jwt = new google.auth.JWT(clientEmail,null,privateKey,['https://www.googleapis.com/auth/spreadsheets'])
  await jwt.authorize()
  const sheets = google.sheets({version:'v4',auth:jwt})
  const values=[[new Date().toISOString(),lead.name||'',lead.dob||'',lead.email||'',lead.phone||'',lead.passport||'',lead.origin||'',lead.destination||'',lead.departDate||'',lead.returnDate||'',lead.budget||'',lead.notes||'',lead.consent? 'Yes':'No', lead.booking? 'Yes':'No' ]]
  await sheets.spreadsheets.values.append({spreadsheetId:SHEET_ID,range:'Sheet1!A:O',valueInputOption:'USER_ENTERED',requestBody:{values}})
}

async function sendEmail(lead){
  if(!ADMIN_EMAIL) return
  let transporter = nodemailer.createTransport({ service:'gmail', auth:{ user:ADMIN_EMAIL, pass:process.env.EMAIL_PASSWORD } })
  await transporter.sendMail({ from:ADMIN_EMAIL,to:ADMIN_EMAIL,subject:`New Lead: ${lead.name||'No name'}`,text:JSON.stringify(lead,null,2) })
}

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'})
  const lead=req.body
  try{
    if(process.env.SHEET_ID) await appendToSheet(lead)
    if(process.env.ADMIN_EMAIL) await sendEmail(lead)
    return res.status(200).json({ok:true})
  }catch(err){ console.error(err); return res.status(500).json({error:err.message||'Server error'}) }
}
