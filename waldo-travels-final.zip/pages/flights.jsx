import Layout from '../components/Layout'
import Link from 'next/link'
export default function Flights(){
  return (
    <Layout>
      <div className="max-w-4xl mx-auto py-12 px-4">
        <h2 className="text-2xl font-bold">Sample Flight Deals</h2>
        <p className="mt-2 text-slate-600">These are sample offers. Fill the lead form and we'll find live fares for you.</p>
        <div className="mt-6 grid gap-4">
          <div className="p-4 bg-white rounded-xl shadow">
            <div className="font-semibold">Delhi ↔ New York</div>
            <div className="text-sm text-slate-500">Starting ₹60,000</div>
            <div className="mt-3"><Link href="/booking"><a className="underline">Get this offer</a></Link></div>
          </div>
          <div className="p-4 bg-white rounded-xl shadow">
            <div className="font-semibold">Mumbai ↔ San Francisco</div>
            <div className="text-sm text-slate-500">Starting ₹68,000</div>
            <div className="mt-3"><Link href="/booking"><a className="underline">Get this offer</a></Link></div>
          </div>
        </div>
      </div>
    </Layout>
  )
}
