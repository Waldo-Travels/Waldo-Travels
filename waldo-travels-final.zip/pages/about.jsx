import Layout from '../components/Layout'
export default function About(){
  return (
    <Layout>
      <div className="max-w-3xl mx-auto py-12 px-4">
        <h2 className="text-2xl font-bold">About Waldo Travels</h2>
        <p className="mt-3 text-slate-600">We help passengers find the best flights to the USA. Personalised support for visas, transfers and more.</p>
      </div>
    </Layout>
  )
}
