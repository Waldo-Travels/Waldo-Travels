import Link from 'next/link'
import Layout from '../components/Layout'

export default function Home(){
  return (
    <Layout>
      <div className="max-w-4xl mx-auto py-12 px-4">
        <h1 className="text-3xl font-bold">Waldo Travels</h1>
        <p className="mt-3 text-slate-600">Best USA flight deals and personalised itineraries. Fill the lead form to get offers.</p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <Link href="/flights"><a className="p-4 bg-white rounded-xl shadow block">Search Flights</a></Link>
          <Link href="/booking"><a className="p-4 bg-white rounded-xl shadow block">Make a Booking</a></Link>
        </div>
      </div>
    </Layout>
  )
}
