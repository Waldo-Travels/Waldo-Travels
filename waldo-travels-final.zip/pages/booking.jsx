import Layout from '../components/Layout'
import BookingForm from '../components/BookingForm'

export default function Booking(){
  return (
    <Layout>
      <div className="max-w-3xl mx-auto py-12 px-4">
        <h2 className="text-2xl font-bold">Booking</h2>
        <p className="mt-2 text-slate-600">Fill the booking request. For payments we use secure payment gateway (no card data collected on this site).</p>
        <div className="mt-6"><BookingForm /></div>
      </div>
    </Layout>
  )
}
