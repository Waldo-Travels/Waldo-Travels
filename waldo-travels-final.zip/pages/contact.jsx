import Layout from '../components/Layout'
import dynamic from 'next/dynamic'
const LeadForm = dynamic(()=>import('../components/LeadForm'),{ssr:false})
export default function Contact(){
  return (
    <Layout>
      <div className="max-w-3xl mx-auto py-12 px-4">
        <h2 className="text-2xl font-bold">Contact & Lead Form</h2>
        <p className="mt-2 text-slate-600">Share your travel details and we'll contact you with options.</p>
        <div className="mt-6"><LeadForm /></div>
      </div>
    </Layout>
  )
}
