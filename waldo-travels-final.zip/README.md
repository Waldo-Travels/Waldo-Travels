Waldo Travels - Multi-page Next.js site (lead generation)

This project intentionally DOES NOT collect raw card or CVV details.
When you're ready to accept payments, integrate Stripe/Razorpay checkout (server-side) and do NOT store card numbers on your server.

Quick start:
1. Extract project
2. npm install
3. Create .env.local with required env vars (see below)
4. npm run dev

.env.local example:
SHEET_ID=your_sheet_id
GOOGLE_SERVICE_ACCOUNT_EMAIL=service-account@project.iam.gserviceaccount.com
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
ADMIN_EMAIL=johnsmith.singh63@gmail.com
EMAIL_PASSWORD=your_gmail_app_password

Google Sheets:
- Create Google Cloud project, enable Sheets API, create service account, download JSON.
- Share your sheet with the service account email.

Deploy:
- Push to GitHub and import to Vercel (or use Vercel CLI).
