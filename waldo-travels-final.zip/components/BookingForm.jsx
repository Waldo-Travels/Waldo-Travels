import React, {useState} from 'react'

export default function BookingForm(){
  const [form,setForm]=useState({name:'',email:'',phone:'',origin:'',destination:'United States',departDate:'',returnDate:'',notes:''})
  const [status,setStatus]=useState({loading:false,msg:null,err:false})

  function handleChange(e){ const {name,value}=e.target; setForm(p=>({...p,[name]:value})) }

  async function submitBooking(e){
    e.preventDefault()
    if(!form.name||!form.email||!form.phone){ setStatus({loading:false,msg:'Name, email & phone required',err:true}); return }
    setStatus({loading:true,msg:null,err:false})
    try{
      const res = await fetch('/api/leads',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...form,booking:true})})
      const data = await res.json()
      if(!res.ok) throw new Error(data?.error||'Server error')
      setStatus({loading:false,msg:'Booking request received. We will contact you for payment.',err:false})
      setForm({name:'',email:'',phone:'',origin:'',destination:'United States',departDate:'',returnDate:'',notes:''})
    }catch(err){ setStatus({loading:false,msg:'Server error. Try again later.',err:true}) }
  }

  return (
    <div>
      <form onSubmit={submitBooking} className="bg-white p-4 rounded-xl shadow space-y-3">
        <input name="name" value={form.name} onChange={handleChange} className="input w-full" placeholder="Full name*" />
        <input name="email" value={form.email} onChange={handleChange} className="input w-full" placeholder="Email*" />
        <input name="phone" value={form.phone} onChange={handleChange} className="input w-full" placeholder="Phone*" />
        <input name="origin" value={form.origin} onChange={handleChange} className="input w-full" placeholder="Origin city" />
        <input name="destination" value={form.destination} onChange={handleChange} className="input w-full" placeholder="Destination" />
        <div className="grid grid-cols-2 gap-2">
          <input type="date" name="departDate" value={form.departDate} onChange={handleChange} className="input" />
          <input type="date" name="returnDate" value={form.returnDate} onChange={handleChange} className="input" />
        </div>
        <textarea name="notes" value={form.notes} onChange={handleChange} className="input w-full" placeholder="Notes or passenger info"></textarea>

        <div className="text-sm text-slate-600">For payments we do NOT collect card details on this site. Click the secure payment button after we contact you.</div>
        <button type="submit" className="w-full py-2 bg-rose-500 text-white rounded-xl">Submit Booking Request</button>
      </form>

      <div className="mt-4">
        <div className="max-w-md mx-auto">
          <div className="p-4 bg-white rounded-xl shadow">
            <div className="font-semibold">Secure Payment (placeholder)</div>
            <p className="text-sm text-slate-600">When you're ready to pay, we'll send a secure payment link (Stripe / Razorpay). We do not collect card numbers here.</p>
            <a className="inline-block mt-3 py-2 px-4 bg-indigo-600 text-white rounded" href="mailto:johnsmith.singh63@gmail.com?subject=Request%20for%20secure%20payment%20link">Request Payment Link (email)</a>
          </div>
        </div>
      </div>

      <style jsx>{`.input{padding:0.5rem;border:1px solid #eee;border-radius:0.5rem}.input:focus{outline:none;border-color:#6366f1;box-shadow:0 0 0 4px rgba(99,102,241,0.08)}`}</style>
    </div>
  )
}
