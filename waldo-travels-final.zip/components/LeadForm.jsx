import React, {useState} from 'react'

export default function LeadForm(){
  const [form,setForm]=useState({name:'',dob:'',email:'',phone:'',passport:'',origin:'',destination:'United States',departDate:'',returnDate:'',budget:'',notes:'',consent:false})
  const [status,setStatus]=useState({loading:false,msg:null,err:false})

  function handleChange(e){ const {name,value,type,checked}=e.target; setForm(p=>({...p,[name]:type==='checkbox'?checked:value})) }
  function validate(){ if(!form.name||!form.email||!form.phone) return 'Name,email & phone required'; if(!/^\S+@\S+\.\S+$/.test(form.email)) return 'Enter valid email'; return null }

  async function submitLead(e){
    e.preventDefault()
    const v=validate(); if(v){ setStatus({loading:false,msg:v,err:true}); return }
    setStatus({loading:true,msg:null,err:false})
    try{
      const res = await fetch('/api/leads',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)})
      const data = await res.json()
      if(!res.ok) throw new Error(data?.error||'Server error')
      setStatus({loading:false,msg:'Thanks! We received your request.',err:false})
      setForm({name:'',dob:'',email:'',phone:'',passport:'',origin:'',destination:'United States',departDate:'',returnDate:'',budget:'',notes:'',consent:false})
    }catch(err){ setStatus({loading:false,msg:'Server error. Try again later.',err:true}) }
  }

  return (
    <form onSubmit={submitLead} className="bg-white p-4 rounded-xl shadow space-y-3">
      <input name="name" value={form.name} onChange={handleChange} className="input w-full" placeholder="Full name*" />
      <input type="date" name="dob" value={form.dob} onChange={handleChange} className="input w-full" />
      <input name="email" value={form.email} onChange={handleChange} className="input w-full" placeholder="Email*" />
      <input name="phone" value={form.phone} onChange={handleChange} className="input w-full" placeholder="Phone*" />
      <input name="passport" value={form.passport} onChange={handleChange} className="input w-full" placeholder="Passport number (optional)" />
      <input name="origin" value={form.origin} onChange={handleChange} className="input w-full" placeholder="Origin city" />
      <input name="destination" value={form.destination} onChange={handleChange} className="input w-full" placeholder="Destination" />
      <div className="grid grid-cols-2 gap-2">
        <input type="date" name="departDate" value={form.departDate} onChange={handleChange} className="input" />
        <input type="date" name="returnDate" value={form.returnDate} onChange={handleChange} className="input" />
      </div>
      <input name="budget" value={form.budget} onChange={handleChange} className="input w-full" placeholder="Budget estimate" />
      <textarea name="notes" value={form.notes} onChange={handleChange} className="input w-full" placeholder="Special requests"></textarea>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="consent" checked={form.consent} onChange={handleChange}/> I agree to be contacted</label>
      <button type="submit" className="w-full py-2 bg-rose-500 text-white rounded-xl">{status.loading?'Sending...':'Submit request'}</button>
      {status.msg && <div className={`text-sm ${status.err?'text-red-600':'text-green-600'}`}>{status.msg}</div>}
      <style jsx>{`.input{padding:0.5rem;border:1px solid #eee;border-radius:0.5rem}.input:focus{outline:none;border-color:#f43f5e;box-shadow:0 0 0 4px rgba(250,204,210,0.4)}`}</style>
    </form>
  )
}
