import Link from 'next/link'
export default function Layout({children}){
  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50 to-white">
      <header className="bg-white shadow">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="font-bold text-xl">Waldo Travels</div>
          <nav className="space-x-4 text-sm text-slate-600">
            <Link href="/"><a>Home</a></Link>
            <Link href="/flights"><a>Flights</a></Link>
            <Link href="/about"><a>About</a></Link>
            <Link href="/contact"><a>Contact</a></Link>
          </nav>
        </div>
      </header>
      <main>{children}</main>
      <footer className="max-w-5xl mx-auto px-4 py-6 text-sm text-slate-500">© {new Date().getFullYear()} Waldo Travels • johnsmith.singh63@gmail.com</footer>
    </div>
  )
}
