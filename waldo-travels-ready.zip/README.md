Waldo Travels - Multi-page Next.js site (lead generation)

How to use:
1. Extract this folder.
2. Run `npm install`
3. Create .env.local with required env vars (see docs in code).
4. Run `npm run dev` and open http://localhost:3000
